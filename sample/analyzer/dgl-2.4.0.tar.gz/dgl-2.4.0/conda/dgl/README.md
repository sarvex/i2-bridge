conda recipe
===

Build the package with `conda build .`
