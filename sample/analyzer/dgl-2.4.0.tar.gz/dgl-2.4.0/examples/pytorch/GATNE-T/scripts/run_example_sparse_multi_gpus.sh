python src/main_sparse_multi_gpus.py --input data/example
