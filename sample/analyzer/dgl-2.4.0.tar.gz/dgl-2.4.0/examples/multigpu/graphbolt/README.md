# Multi-gpu training with GraphBolt data loader

## How to run

```bash
python node_classification.py --gpu=0,1
```