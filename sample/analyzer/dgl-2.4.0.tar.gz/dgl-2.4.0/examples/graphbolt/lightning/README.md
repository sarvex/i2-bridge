# Node classification on homogeneous graph with GraphSAGE

## Run on `ogbn-products` dataset

### Command
```
python3 node_classification.py
```

### Results
```
Valid Accuracy: 0.907
```