## How to run the code?

```bash
python link_prediction.py
```

Results (10 epochs):
```
Valid MRR 0.7040
Test MRR 0.7043
```