Resources
=========
* If you are new to deep learning, `Dive into Deep Learning <http://diveintodeeplearning.org>`__
  is a nice book to start with.
* `Pytorch tutorials <https://pytorch.org/tutorials/>`__
* Thomas Kipf's `blog on Graph Convolutional Networks <https://tkipf.github.io/graph-convolutional-networks/>`__
