User Guide
==========

.. toctree::
  :maxdepth: 2
  :titlesonly:

  graph
  message
  nn
  data
  training
  minibatch
  distributed
  mixed_precision
