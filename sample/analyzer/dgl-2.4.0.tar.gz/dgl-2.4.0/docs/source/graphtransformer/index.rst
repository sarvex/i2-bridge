🆕 Tutorial: Graph Transformer
==========

This tutorial introduces the **graph transformer** (:mod:`~dgl.nn.gt`) module,
which is a set of utility modules for building and training graph transformer models.

.. toctree::
  :maxdepth: 2
  :titlesonly:

  model
  data
