.. _apioptim:

dgl.optim
=========

.. automodule:: dgl.optim

Node embedding optimizer
-------------------------
.. currentmodule:: dgl.optim.pytorch

.. autoclass:: SparseAdagrad
.. autoclass:: SparseAdam