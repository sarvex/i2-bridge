API Reference
=============

.. toctree::
   :maxdepth: 2

   dgl
   dgl.data
   dgl.dataloading
   dgl.DGLGraph
   dgl.distributed
   dgl.function
   nn-pytorch
   nn-tensorflow
   nn-mxnet
   dgl.ops
   dgl.sampling
   udf
   transforms
