사용자 가이드[시대에 뒤쳐진]
=====================

.. toctree::
  :maxdepth: 2
  :titlesonly:

  graph
  message
  nn
  data
  training
  minibatch
  distributed
  mixed_precision


이 한글 버전 DGL 사용자 가이드 2021년 11월 기준의 영문 :ref:`(User Guide) <guide-index>` 을 Amazon Machine Learning Solutions Lab의 김무현 Principal Data Scientist가 번역한 것입니다. 오류 및 질문은 `muhyun@amazon.com` 으로 보내주세요.