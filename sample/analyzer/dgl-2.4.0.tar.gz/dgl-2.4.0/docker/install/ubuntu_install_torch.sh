#!/bin/bash
# install torch
pip2 install torch==1.0.1 torchvision==0.2.2
pip3 install torch==1.0.1 torchvision==0.2.2
