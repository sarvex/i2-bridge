from .graphpred import GraphpredPipeline
from .linkpred import LinkpredPipeline
from .nodepred import NodepredPipeline
from .nodepred_sample import NodepredNsPipeline
