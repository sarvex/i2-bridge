# DGL-LifeSci

DGL-LifeSci is moved [here](https://github.com/awslabs/dgl-lifesci).
